export default function Contact(props){
    return(
        <div>
            <div>Contact Page</div>
        </div>
    );
}