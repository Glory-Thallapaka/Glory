export default function NotFound(props){
    return(
        <div>
            Not found page from component
        </div>
    );
}