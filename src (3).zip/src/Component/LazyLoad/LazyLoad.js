export default function LazyLoad(props) {
    return <div>Lazy Load COmponent</div>;
}
