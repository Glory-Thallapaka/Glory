export function Home(props){
    console.log(props);
    return(
        <div>
            <div>Home Page</div>
        </div>
    );
}