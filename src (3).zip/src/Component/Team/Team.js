import {withRouter} from 'react-router-dom';
function Team(props){
    console.log(props);
    return<div>Team Page</div>
}
export default withRouter(Team);