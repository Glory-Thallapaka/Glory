export function Footer(props){
    return(
        <div>
            <div>Footer Page</div>
        </div>
    );
}