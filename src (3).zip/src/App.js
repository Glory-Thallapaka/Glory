import './App.css';
import {
    BrowserRouter,
    Route,
    Redirect,
    Routes,
    Router,
} from 'react-router-dom';
import { Footer } from './Component/Footer/Footer';
import { Header } from './Component/Header/Header';
import { lazy, Suspense } from 'react';
const About =lazy(()=>
import(/* webpackChunkName:"About" */'./Component/About/About' ),
);
const Contact =lazy(()=>
import(/* webpackChunkName:"About" */'./Component/Contact/Contact' ),
);
const Posts =lazy(()=>
import(/* webpackChunkName:"About" */'./Component/Posts/Posts' ),
);
const NotFound =lazy(()=>
import(/* webpackChunkName:"About" */'./Component/NotFound/NotFound' ),
);

function App() {
    let isAuthenticate = true;
    return (
        <BrowserRouter>
            <Header />
            <div className='container mx-auto'>
                <div>
                    <Suspense fallback={<div>Loading....</div>}>
                        <Router>
                            {isAuthenticate && (
                                <Route path='/about' Component={About} />
                            )}
                            <Routes>
                            <Route path='/contact' Component={Contact} />
                            <Route path='/posts' Component={Posts} />

                            <Redirect from='/' to='/posts' exact />
                            <Route path='*' Component={NotFound} />
                                </Routes>
                        </Router>
                    </Suspense>
                </div>
                <Footer />
            </div>
        </BrowserRouter>
    );
}

export default App;

