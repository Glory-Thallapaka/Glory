import React, { useEffect, useState } from "react";
import { useDispatch, useSelector, useStore } from "react-redux";
export function Dropdown(){
    const{users,selectedUser}=useSelector((state)=>({
        users:state.Reducer.users,
        selectedUser:state.Reducer.selectedUser
    }));
    const [dropDownValue,setDropDownValue]=useState();
    const store=useStore();
    const dispatch=useDispatch();
    useEffect(()=>{
        fetch("./users.json")
        .then((response)=>response.json())
        .then((json)=>{
            dispatch({type:"SET_USER_DATA",payload:json});
            dispatch({type:"SELECTED_USER_DATA",
        payload:json.length>0?json[0]:{}});
        });
});
const tabArray=selectedUser.hasOwnProperty("id")?[selectedUser] : users;
return(
    <div>
        <select onChange={(e)=>{
            if(e.target.value){
                let selected=users?.find((item)=>item.name===e.target.value);
                setDropDownValue(e.target.value||"");
                dispatch({type:"SELECTED_USER_DATA",payload:selected});
             }
        }}
        value={dropDownValue}>
            <option>select</option>
            {users?.map((item)=>{
                return<option value={item.name}>{item.name}</option>;
            })}
        </select><br/><br/><br/><br/>
       <table border="1">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Location</th>
            </tr>
            {tabArray.map((item)=>{
                return(
                    <tr>
                        <td>{item.id}</td>
                        <td>{item.name}</td>
                        <td>{Object.values(item.location).join("")}</td>
                    </tr>
                );
            })}
       </table>
    </div>
);
    
}