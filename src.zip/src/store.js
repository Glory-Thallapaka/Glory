import { createStore,combineReducers} from "redux";

const initialSate={
    users:[
        {
            "id":"123",
            "name":"Glory",
            "location":"Banglore"
        },
        {
            "id":"124",
            "name":"Jhon",
            "location":"chennai" 
        },
        {
            "id":"125",
            "name":"Rebecca",
            "location":"Pune" 
        }
    ],
    selectedUser:{},
    
};
const Reducer=(state=initialSate,action)=>{
    switch(action.type){
        case 'SET_USER_DATA':
            return {
                ...state,
                users:action.payload
            };
        case 'SELECTED_USER_DATA':
            return{
                ...state,
                selectedUser:action.payload
            };
            default:
                return state;
    }
};
export const store =createStore(combineReducers({Reducer}));

