export const filter=()=>{
    return{
        type:'FILTER',
    };
};