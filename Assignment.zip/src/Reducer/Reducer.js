const initialState = {
  counterValue: 10,
};

const Reducer = (state = initialState, action) => {
  switch (action.type) {
    case 'INCREMENT':
      return {
        ...state,
        counterValue: state.counterValue+2,
      };
      case 'MULTIPLY':
      return {
        ...state,
        counterValue: state.counterValue*2,
      };
      case 'RESET':
      return {
        ...state,
        counterValue:0,
      };
    default:
      return state;
  }
};

export default Reducer;
