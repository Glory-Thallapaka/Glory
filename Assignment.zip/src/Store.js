import { createStore } from 'redux';
import DataReducer from './Reducer/Reducer';


const store = createStore(DataReducer);

export default store;
