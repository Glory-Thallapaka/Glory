export const increment = () => {
    return {
      type: 'INCREMENT',
    };
  };
  export const multiply = () => {
    return {
      type: 'MULTIPLY',
    };
  };
  export const reset = () => {
    return {
      type: 'RESET',
    };
  };