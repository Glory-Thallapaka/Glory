import React from 'react';
import { Provider } from 'react-redux';
import store from './Store';
import Counter from './Component/Counter';

export default function App() {
  return (
    <Provider store={store}>
      <div>
        <h1>OPERATIONS</h1>
        <Counter />
      </div>
    </Provider>
  );
}
