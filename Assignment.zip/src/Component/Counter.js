import React from 'react';
import { connect } from 'react-redux';
import { increment, multiply, reset } from '../Actions/counterAction.js';

function Counter(props) {
  return (
    <div>
      <h1> Counter= {props.counterValue}</h1>
      <button onClick={props.increment}>Increment by 2</button>
      <button onClick={props.multiply}>Multiply by 2 </button>
      <button onClick={props.reset}>Reset </button>
    </div>
  );
}

const mapStateToProps = (state) => {
  return {
    counterValue: state.counterValue,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    increment:()=>dispatch(increment()),
    multiply:()=>dispatch(multiply()),
    reset:()=>dispatch(reset()),
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(Counter);
