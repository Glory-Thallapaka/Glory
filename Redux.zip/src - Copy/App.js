import React from "react";
import { Provider } from "react-redux";
import Container from "./Component/Container";
import store from "./redux/store";
function App(){
  return(
    <Provider store={store}>
      <div>
        <Container/>
      </div>
    </Provider>
  )
}
export default App;