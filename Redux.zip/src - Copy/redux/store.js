import { createStore } from "redux";
import reducer from "../store/reducer1";
const store=createStore(reducer)
export default store;