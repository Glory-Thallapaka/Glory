import React from "react";
import { buyCake } from "../store"
import {connect} from 'react-redux';
import { BUY_CAKE } from "../redux";
function Container(props){
    return(
        <div>
            <h2>No.Of cakes-{props.noOfCakes}</h2>
            <button onClick={buyCake}>BUY_CAKE</button>
        </div>
    )
}
const mapStateToProps=state=>{
    return{
        noOfCakes:state.noOfCakes
    }
}
function mapDispatchToProps(dispatch) 
{ 
    console.log("buycake")
    return({buyCake: () =>
     {dispatch(BUY_CAKE)} }) }
export default connect(mapStateToProps,mapDispatchToProps)(Container);