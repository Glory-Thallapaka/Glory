import { BUY_CAKE } from "./stype"

const buyCake=()=>{
    console.log("Action")
    return (dispatch) => { dispatch
        ({
        type:"BUY_CAKE"
         }) }
}
export default buyCake;