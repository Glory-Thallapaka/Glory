export const INCREMENT_COUNT='Increment Count';

export function incrementCount(){
    return{
        type:INCREMENT_COUNT,
    };
}