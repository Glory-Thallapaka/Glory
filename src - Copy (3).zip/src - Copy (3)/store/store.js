import {createStore} from 'redux';
import { PostsReducer } from './reducer/PostReducer';

const store=createStore(PostsReducer);
export default store;