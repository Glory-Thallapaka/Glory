import './App.css';
import PostList from './Component/PostList/Postlist';

function App(){
    return(
        <div>
            <PostList/>
        </div>
    );
}

export default App;