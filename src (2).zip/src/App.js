import './App.css';
import { useState } from 'react';
import Counter from './Component/Counter';

function App() {
    const [showCounter, setShowCounter] = useState(true);
    return (
        <div className='container mx-auto'>
            <div>
                <button
                    className='bg-green-600 text-white px-3 py-1'
                    onClick={() => setShowCounter(!showCounter)}
                >
                    Toggle component
                </button>
            </div>
            {showCounter && <Counter/>}
        </div>
    );
}

export default App;