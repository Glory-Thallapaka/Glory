import { useEffect, useRef, useState } from "react"


const Counter=()=>{
    const isMounted=useRef(false);
    const [counter,setCounter]=useState(0);
    const [x, setX]=useState(0);
    
    //when componentdidMount Mounted and update
    useEffect(()=>{
        console.log('Fires mounted and also updated');
        document.title='count:'+counter
    });
    //when component only mounted
    useEffect(()=>{
        console.log('Fires only mounted');
    },[x,counter]);

    //when component unmounted and also update
    useEffect(()=>{
        return()=>{
            console.log('Fires when unmounted and also on update');
        };
    });

    //when component unmounted
    useEffect(()=>{
        return()=>{
            console.log('fires when mounted');
        };
    },[]);

    //when component only updated

    useEffect(()=>{
        if(isMounted.current){
            console.log('fires when updated');
        }
        else{
            isMounted.current=true;
        }
    });
    return(
        <div>
            <div>Counter Component</div>
            <div>You Clicked {counter} times</div>
            <div>X value: {x}</div>
            <div>
                <button className="bg-red-500 px-3 py-1 text-white"
                onClick={()=>setX(x+1)}>
                    Increment X
                </button>
            </div>
        </div>
    );
};
export default Counter;